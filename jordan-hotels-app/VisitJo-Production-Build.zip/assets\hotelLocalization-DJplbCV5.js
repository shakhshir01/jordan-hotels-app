const i=(a,n)=>{if(String(n||"").toLowerCase().startsWith("ar")){const t=a?.nameAr||a?.name_ar;if(typeof t=="string"&&t.trim())return t}const r=a?.name;return typeof r=="string"?r:""};export{i as g};
